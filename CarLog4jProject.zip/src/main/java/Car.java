
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Car {
    private static final Logger logger = LogManager.getLogger(Car.class);

    private String brand;
    private String model;
    private int year;
    private double price;

    public Car(String brand, String model, int year, double price) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.price = price;
        logger.info("Шинэ машин үүсгэгдлээ: {}, {}, {}, {}", brand, model, year, price);
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        logger.debug("Brand-г {} болгож өөрчиллөө", brand);
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        logger.debug("Model-г {} болгож өөрчиллөө", model);
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        logger.debug("Year-г {} болгож өөрчиллөө", year);
        this.year = year;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        logger.debug("Price-г {} болгож өөрчиллөө", price);
        this.price = price;
    }

    public void displayInfo() {
        logger.info("Машины мэдээллийг хэвлэж байна.");
        System.out.println("Brand: " + brand + ", Model: " + model + ", Year: " + year + ", Price: " + price);
    }

    public static void main(String[] args) {
        logger.info("Програм эхэллээ.");
        Car myCar = new Car("Toyota", "Prius 51", 2019, 10000);
        myCar.displayInfo();
        logger.info("Програм дууслаа.");
    }
}
